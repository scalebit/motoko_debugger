int inc(int input) {
  return input + 1;
}
